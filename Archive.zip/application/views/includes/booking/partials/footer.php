<footer class="footer d-flex flex-column">
  <div class="footer-content">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="logo-footer">
            <div class="logo"><span class="text1">Working</span><span class="text2">Hub.</span></div>
            <span>Website untuk mencari dan menyewa ruangan untuk keperluan meeting, event kantor, workshop, seminar, dan masih banyak lagi.</span>
          </div>
        </div>
        <div class="col-md-2">
          <div class="logo-footer">
            <h5 class="pd-headline-footer">Tentang WorkingHub.</h5>
            <p>Tentang Kami</p>
            <p>Partner Gedung</p>
            <p>Ketentuan Pemesanan</p>
            <p>Kontak Kami</p>
          </div>
        </div>
        <div class="col-md-2">
          <div class="logo-footer">
            <h5 class="pd-headline-footer">Lokasi</h5>
            <p>Jakarta</p>
            <p>Tangerang</p>
            <p>Bandung</p>
            <p>Yogyakarta</p>
            <p>Surabaya</p>
            <p>Lainnya</p>
          </div>
        </div>
        <div class="col-md-2">
          <div class="logo-footer">
            <h5 class="pd-headline-footer">Kegunaan</h5>
            <p>Meeting</p>
            <p>Workshop</p>
            <p>Seminar</p>
            <p>Ruang Kerja</p>
            <p>Lainnya</p>
          </div>
        </div>
        <div class="col-md-2">
          <div class="logo-footer">
            <h5 class="pd-headline-footer">Metode Pembayaran</h5>
            <span>Website untuk mencari dan menyewa ruangan untuk keperluan meeting, event kantor, workshop, seminar, dan masih banyak lagi.</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright">
    <div class="d-flex justify-content-center">
      <p class="text-muted text-center text-md-left">Copyright © 2022 <a href="#" target="#">WorkingHub.</a> All rights reserved</p>
    </div>
  </div>
</footer>