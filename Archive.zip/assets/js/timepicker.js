// tempusdominus-bootstrap-4
$(function() {
  'use strict';

  $('#jambuka').datetimepicker({
    format: 'LT'
  });

  $('#jamtutup').datetimepicker({
    format: 'LT'
  });
});